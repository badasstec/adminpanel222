<?php
session_start();

// Check if the user is logged in and is an admin, if not then redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin'){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
            <title>admin dashboard</title>
        <link rel="stylesheet" href="style.css">
</head>


<body>
    
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><i class='bx bx-book-open' ></i></span>
                        <span style="padding-right: 100px;" class="title"> <h2><?php echo htmlspecialchars($_SESSION["username"]);?>(Admin)</h2></span>
                        
                    </a>
                </li>
                <li>
                    <a href="index2.php">
                        <span class="icon"><i class='bx bxs-dashboard'></i></span>
                        <span class="title">dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="price.php">
                        <span class="icon"><i class='bx bx-group'></i></span>
                        <span class="title">prices</span>
                    </a>
                </li>

                <li>
                    <a href="mail.php">
                        <span class="icon"><i class='bx bx-message-rounded-dots'></i></span>
                        <span class="title">mail customers</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon"><i class='bx bx-help-circle'></i></span>
                        <span class="title">help</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><i class='bx bx-cog'></i></span>
                        <span class="title">settings</span>
                    </a>
                </li>
                
                <li>
                    <a href="../admin_online_users.php">
                        <span class="icon"><i class='bx bxs-lock-alt'></i></span>
                        <span class="title">online_users</span>
                    </a>
                </li>
                <li>
                    <a href="../logout.php">
                        <span class="icon"><i class='bx bx-log-in'></i></span>
                        <span class="title">sign out</span>
                    </a>
                </li>
            </ul>
        </div>


                <div class="main">
                    <div class="topbar">
                        <div class="toggle">
                            <i class='bx bx-menu' ></i>
                        </div>
                        <div class="search">
                            <label>
                            <input type="text" placeholder="search here">
                            <i class='bx bx-search' ></i>
                            </label>
                        </div>
                        <div class="user">
                            <!-- <img src="img/customer2.jpg" width="200px"> -->
                        </div>
                    </div>

                    <div class="cardbox">
                        <div class="card">
                            <div>
                                <div class="numbers">1,504</div>
                                <div class="cardname">registered account</div>
                            </div>

                        <div class="iconbx">
                            <i class='bx bx-show'></i>
                        </div>
                        </div>
                        <div class="card">
                            <div>
                                <div class="numbers">80</div>
                                <div class="cardname">admins</div>
                            </div>

                        <div class="iconbx">
                            <i class='bx bx-cart'></i>
                        </div>
                        </div>
                        <div class="card">
                            <div>
                                <div class="numbers">205</div>
                                <div class="cardname">comments</div>
                            </div>

                        <div class="iconbx">
                            <i class='bx bx-chat'></i>
                        </div>
                        </div>
                        <div class="card">
                            <div>
                                <div class="numbers">premium</div>
                                <div class="cardname">$7,542</div>
                            </div>

                        <div class="iconbx">
                            <i class='bx bx-money'></i>
                        </div>
                        </div>
                    </div>

                    <div class="details">
                        <div class="recentorders" style="width: 90%;">
                            <div class="cardheader">
                                <h2>recent bookings</h2>
                                <a href="#" class="btn">view all</a>
                            </div>

                            <table>
                                <thead>
                                    <tr>
                                        <td>name</td>
                                        <td>price</td>
                                        <td>payment</td>
                                        <td>status</td>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td>walker hayes</td>
                                        <td>$4000</td>
                                        <td>paid</td>
                                        <td><span class="status delivered">Booked</span></td>
                                    </tr>
                                        <td>dustin lynch</td>
                                        <td>$1200</td>
                                        <td>due</td>
                                        <td><span class="status pending">pending</span></td>
                                    </tr>
                                    <tr>
                                        <td>ryan phillippe</td>
                                        <td>$2000</td>
                                        <td>paid</td>
                                        <td><span class="status return">return</span></td>
                                    </tr>
                                    <tr>
                                        <td>walker hayes</td>
                                        <td>$4000</td>
                                        <td>due</td>
                                        <td><span class="status inprogress">in progress</span></td>
                                    </tr>
                                    <tr>
                                        <td>bill burr</td>
                                        <td>$5000</td>
                                        <td>paid</td>
                                        <td><span class="status delivered">Booked</span></td>
                                    </tr>
                                </tr>
                                <td>elon musk</td>
                                <td>$12000</td>
                                <td>due</td>
                                <td><span class="status pending">pending</span></td>
                            </tr>
                            <tr>
                                <td>johny depp</td>
                                <td>$4000</td>
                                <td>paid</td>
                                <td><span class="status return">return</span></td>
                            </tr>
                            <tr>
                                <td>elon musk</td>
                                <td>$12000</td>
                                <td>due</td>
                                <td><span class="status inprogress">in progress</span></td>
                            </tr>
                                </tbody>
                            </table>
                        </div>


                        <div class="recentcustomers">
                            <div class="cardheader">
                                <h2>recent fans</h2>
                            </div>

                            <table>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer1.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>david <br><span>italy</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer6.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>john <br><span>canada</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer5.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>khavic <br><span>india</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>micheal <br><span>australia</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer3.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>frank <br><span>spain</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer1.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>daniel <br><span>canada</span></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="60px">
                                        <div class="imgbx"><img src="img/customer4.jpg"  width="200px"></div>
                                    </td>
                                    <td>
                                        <h4>jane <br><span>Us</span></h4>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
    </div>
    </div>
    <script src="main.js"></script>
</body>
</html>